package com.service.onestopbilling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnestopBillingApplicationTests {

	@Test
	void contextLoads() {
	}

}
