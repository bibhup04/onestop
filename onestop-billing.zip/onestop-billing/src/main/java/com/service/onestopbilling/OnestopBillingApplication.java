package com.service.onestopbilling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnestopBillingApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnestopBillingApplication.class, args);
	}

}
