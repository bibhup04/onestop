package com.service.onestopserviceregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnestopServiceRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
