package com.service.onestopauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnestopAuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnestopAuthApplication.class, args);
	}

}
