package com.service.ottstubs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OttStubsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OttStubsApplication.class, args);
	}

}
