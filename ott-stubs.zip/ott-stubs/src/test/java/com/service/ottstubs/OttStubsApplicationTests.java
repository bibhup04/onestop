package com.service.ottstubs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OttStubsApplicationTests {

	@Test
	void contextLoads() {
	}

}
