package com.service.onestopgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnestopGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnestopGatewayApplication.class, args);
	}

}
